# 三角洲行动游戏反馈洞察助手

## AI 作品集入口

- `index.html`：面试官入口页。
- `dashboard/index.html`：交互式反馈洞察看板。
- `portfolio/case-study.pdf`：三页案例。
- `portfolio/demo/demo-preview.gif`：动态演示预览。
- `portfolio/demo-script.md`：两分钟讲解脚本。
- `resume/AI作品集简历条目.md`：可直接加入简历的条目。
- `deliverables/面试官版-三角洲反馈洞察.zip`：可离线发送的完整作品集。

> 作品集定位为“AI 辅助数据分析与运营洞察”，不宣称训练模型、生产上线或业务因果效果。

这是一个面向游戏运营、产品分析和策划场景的反馈分析项目。项目从 Steam、苹果应用商店、TapTap 和 B站读取公开评论，完成匿名化、标准化、主题分类、情绪判断、严重度评估、人工抽检、看板和报告生成。

## 当前成果

- 有效评论：1,431 条。
- 来源数量：4 类。
- Steam：800 条。
- 苹果应用商店：451 条。
- TapTap：162 条。
- B站：18 条。
- 人工抽检：48 条。
- 主题一致率：81.3%。
- 情绪一致率：66.7%。
- 严重度一致率：75.0%。
- 三项全对率：45.8%。`n- Copilot 主题一致率：77.1%。`n- Copilot 情绪一致率：79.2%。`n- Copilot 严重度一致率：81.3%。`n- 独立 AI 复核：60 条样本，主题 68.3%、情绪 63.3%、严重度 61.7%。

## 目录

- `src/`：采集、处理、人工验证接入和看板生成代码。
- `data/raw/`：匿名化原始快照与来源状态。
- `data/processed/`：标准反馈表、分析表、汇总指标和人工抽检数据。
- `dashboard/index.html`：完全离线、可交互的单文件看板。
- `portfolio/`：作品集入口、案例 PDF、截图和演示资产。
- `resume/`：含 AI 作品集的新版简历与更新说明。
- `reports/`：周报、案例研究、分类标准和人工验证报告。
- `work/`：采集探针、验收脚本和中间文件。

## 运行方式

程序只依赖 Node.js 原生模块，不需要安装第三方包。

```powershell
node src/collect.js
node src/process.js
node src/build_dashboard.js
```

可选的低频 B站补充脚本：

```powershell
node src/collect_bilibili_supplement.js
```

## 核心脚本

- `src/collect.js`：读取四类公开来源，保存匿名化快照。
- `src/collect_bilibili_supplement.js`：在平台限流恢复后低频补充 B站评论。
- `src/process.js`：清洗、去重、分类、汇总和人工验证指标计算。
- `src/build_dashboard.js`：将分析数据嵌入离线看板。
- `src/llm_compare.js`：大模型分类对照样本与运行入口。
- `src/create_second_review.js`：生成第二标注者任务。
- `src/evaluate_second_review.js`：计算第二标注者一致率。

## 数据原则

- 只采集公开可见内容。
- 不绕过登录、验证码、访问控制或平台限制。
- 用户名、头像和主页不进入原始快照。
- 作者标识只保留不可逆短哈希。
- 来源、采集时间、页面链接和限制全部记录。
- 不把少量评论外推为全部玩家意见。
- 自动分类必须经过人工抽检和业务解释。

## 已知限制

- Steam 评论接口按时间和游标返回，当前读取最近 365 天。
- Apple 公开 RSS 最多提供最近约 450—500 条评论。
- TapTap 接口显示总量存在上限，本次读取的是公开分页样本。
- B站采集期间触发过平台限流，当前有效样本较少。
- 规则分类对反讽、跨语言和多主题长评仍存在误差。

